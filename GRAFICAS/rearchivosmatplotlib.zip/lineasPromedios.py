import matplotlib.pyplot as linea

# Datos
etiquetas = ['Programación', 'Inglés', 'Proyectos', 'Habilidades']
valores = [4.5, 3, 5, 4]

# Crear el gráfico de líneas
linea.plot(etiquetas, valores, marker='o')

# Añadir los valores en los puntos de quiebre
for i, valor in enumerate(valores):
    linea.text(i, valor + 0.1, str(valor), ha='center')

# Añadir títulos y etiquetas
linea.xlabel('Categorías')
linea.ylabel('Valores')
linea.title('Gráfico de Líneas de Ejemplos')

# Mostrar el gráfico
linea.show()
